#Python Encode Decode Library by Vidak-Becs Mate
